/**
 * Created by Bryan on 24/11/2016.
 */
let person = new Object();
person["name"] = "Jos";
person["age"] = 45;
console.log(person.name + " is " + person.age);
addEventListener("load", demo, false);

function demo() {
    let groeten = document.getElementsByClassName("groet");
    groeten[0].innerHTML = "Jos";
    groeten[1].innerHTML = "Jennifer";
}
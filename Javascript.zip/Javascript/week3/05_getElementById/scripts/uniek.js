addEventListener("load", demo, false);

function demo() {
    let element = document.getElementById("uniek");
    element.innerHTML = "Je ben uniek!";
}

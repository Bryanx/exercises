addEventListener("load", vervangAutoDoorFiets, false);

function vervangAutoDoorFiets() {
    let image = document.getElementsByTagName("img")[0];
    image.src = "images/fiets.jpg";
    image.alt = "fiets";
}






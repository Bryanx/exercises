package minmax;

/**
 * @author Bryan de Ridder
 * @version 1.0 29/11/2016 17:06
 */
public interface MinMax {
    String minimum();
    String maximum();
}
